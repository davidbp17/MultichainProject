<?php
session_start();
include("Chain.php");
$rate = $_POST['ratenum'];
$datetime = $_POST['datetime'];
$comments = $_POST['comments'];
$ratefinal = $rate . "<br>" . $comments;
$toBeRated = $_SESSION['ratee'];
$ratedBy = $_SESSION['name'];
$password="5aRn1W8VHrwzphqNuG6UxzySxHXBHy5fG8hSGi2GXxeo"; 
$chain = new Chain(multichainrpc, $password, localhost, 5000);
$array = $chain->rateUser($toBeRated, $ratedBy, $ratefinal);
header("location:home.php");
?>