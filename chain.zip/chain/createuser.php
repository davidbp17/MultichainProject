<?php include("Chain.php"); 
$name = $_POST['name'];
$password="5aRn1W8VHrwzphqNuG6UxzySxHXBHy5fG8hSGi2GXxeo"; 
$chain = new Chain(multichainrpc, $password, localhost, 5000);
$check = $chain->listUsers();
if (in_array($name, $check))  
{  
	echo("User already exists!");
	sleep(3);
} 
else
{
	$chain->createUser($name);
}
header("location:index.php");
?>