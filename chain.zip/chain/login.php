<?php
session_start();
$name = $_POST["username"];
$_SESSION['name'] = $name;
header("location:home.php");
?>